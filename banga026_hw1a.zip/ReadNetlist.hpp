#include<stdio.h>
#include<string>
#include<iostream>
#include<fstream>
#include<algorithm>
#include<iterator>
#include<ctype.h>
#include"NetlistGraph.hpp"

int read_netlist(NetlistGraph* myNetlist, string FileInput);


